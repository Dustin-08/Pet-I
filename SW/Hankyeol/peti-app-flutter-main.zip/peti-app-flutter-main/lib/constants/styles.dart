class Styles {
  static const double MARGIN = 20.0;

}