package com.example.ondevice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
