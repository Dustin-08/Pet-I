package com.example.firstnote

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
